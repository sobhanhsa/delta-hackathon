import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// این پروژه کاملا محلی است: بدون هیچ فراخوانی به سرویس بیرونی یا اینترنت اجرا می‌شود.
export default defineConfig({
  plugins: [react()],
});
