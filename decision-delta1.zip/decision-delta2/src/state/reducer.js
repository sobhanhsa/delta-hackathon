import { computeAlerts, computeInstallHours } from '../logic/calc.js';

function nowTime() {
  return new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
}

function countCritical(alerts) {
  return alerts.filter((a) => a.severity === 'بحرانی').length;
}

function pushEvent(state, entry) {
  const alertsBefore = countCritical(computeAlerts(state));
  return { alertsBefore };
}

function finalizeEvent(prevState, nextState, base) {
  const alertsAfter = countCritical(computeAlerts(nextState));
  const event = {
    id: `ev-${Date.now()}-${Math.round(Math.random() * 1000)}`,
    time: nowTime(),
    ...base,
    criticalAlertsBefore: pushEventCache.alertsBefore,
    criticalAlertsAfter: alertsAfter,
  };
  return { ...nextState, events: [event, ...nextState.events] };
}

// چون reducer باید خالص بماند، شمارش هشدار "قبل" را همین‌جا و بدون وضعیت خارجی محاسبه می‌کنیم.
let pushEventCache = { alertsBefore: 0 };

function withEvent(state, base, mutate) {
  pushEventCache = pushEvent(state, base);
  const nextState = mutate(state);
  return finalizeEvent(state, nextState, base);
}

export function appReducer(state, action) {
  switch (action.type) {
    case 'ADD_OPPORTUNITY': {
      const opp = { ...action.payload, id: `o-${Date.now()}`, stage: 'جدید' };
      return withEvent(
        state,
        {
          type: 'ثبت فرصت فروش',
          entity: `فرصت جدید — ${opp.quantity} واحد`,
          before: '—',
          after: `${opp.quantity} واحد`,
          reason: 'ثبت فرصت فروش جدید',
        },
        (s) => ({ ...s, opportunities: [...s.opportunities, opp] })
      );
    }

    case 'UPDATE_OPPORTUNITY': {
      const { id, patch } = action.payload;
      return withEvent(
        state,
        {
          type: 'ویرایش فرصت فروش',
          entity: `فرصت ${id}`,
          before: 'مقادیر قبلی فرصت',
          after: 'مقادیر جدید فرصت',
          reason: patch.reason || 'ویرایش اطلاعات فرصت',
        },
        (s) => ({
          ...s,
          opportunities: s.opportunities.map((o) => (o.id === id ? { ...o, ...patch } : o)),
        })
      );
    }

    case 'CONFIRM_OPPORTUNITY': {
      const opp = state.opportunities.find((o) => o.id === action.payload.id);
      if (!opp) return state;
      return withEvent(
        state,
        {
          type: 'قطعی‌شدن فروش',
          entity: `فرصت ${opp.id} (${opp.quantity} واحد)`,
          before: 'در حال مذاکره',
          after: 'تعهد قطعی سازمان',
          reason: 'مرحله فروش به «قطعی‌شده» تغییر کرد',
        },
        (s) => {
          const product = s.products.find((p) => p.id === opp.productId);
          const newOrder = {
            id: `ord-${Date.now()}`,
            customerId: opp.customerId,
            productId: opp.productId,
            quantity: opp.quantity,
            unitPrice: opp.unitPrice,
            confirmedAt: new Date().toISOString().slice(0, 10),
            sourceOpportunityId: opp.id,
          };
          const currentAvailable = s.inventory[opp.productId]?.available ?? 0;
          return {
            ...s,
            opportunities: s.opportunities.map((o) =>
              o.id === opp.id ? { ...o, stage: 'قطعی‌شده' } : o
            ),
            orders: [...s.orders, newOrder],
            inventory: {
              ...s.inventory,
              [opp.productId]: { available: currentAvailable - opp.quantity },
            },
          };
        }
      );
    }

    case 'ADJUST_INVENTORY': {
      const { productId, newValue, reason } = action.payload;
      const before = state.inventory[productId]?.available ?? 0;
      return withEvent(
        state,
        {
          type: 'اصلاح موجودی',
          entity: state.products.find((p) => p.id === productId)?.name || productId,
          before: `${before}`,
          after: `${newValue}`,
          reason,
        },
        (s) => ({
          ...s,
          inventory: { ...s.inventory, [productId]: { available: newValue } },
        })
      );
    }

    case 'ADJUST_CAPACITY': {
      const { availableHours, reason } = action.payload;
      const before = state.capacity.totalHours;
      return withEvent(
        state,
        {
          type: 'اصلاح ظرفیت نصب',
          entity: 'ظرفیت نصب کل',
          before: `${before} ساعت`,
          after: `${availableHours} ساعت`,
          reason,
        },
        (s) => ({ ...s, capacity: { ...s.capacity, totalHours: availableHours } })
      );
    }

    case 'ADD_RECEIPT': {
      const receipt = { ...action.payload, id: `r-${Date.now()}` };
      return withEvent(
        state,
        {
          type: 'ثبت دریافت',
          entity: `دریافت ${receipt.amount.toLocaleString('fa-IR')}`,
          before: `${state.cash.balance.toLocaleString('fa-IR')}`,
          after: `${(state.cash.balance + receipt.amount).toLocaleString('fa-IR')}`,
          reason: 'ثبت دریافت نقدی',
        },
        (s) => ({
          ...s,
          cash: {
            ...s.cash,
            balance: s.cash.balance + receipt.amount,
            receipts: [...s.cash.receipts, receipt],
          },
        })
      );
    }

    case 'ADD_PAYMENT': {
      const payment = { ...action.payload, id: `pay-${Date.now()}` };
      return withEvent(
        state,
        {
          type: 'ثبت پرداخت',
          entity: `پرداخت ${payment.amount.toLocaleString('fa-IR')}`,
          before: `${state.cash.balance.toLocaleString('fa-IR')}`,
          after: `${(state.cash.balance - payment.amount).toLocaleString('fa-IR')}`,
          reason: 'ثبت پرداخت نقدی',
        },
        (s) => ({
          ...s,
          cash: {
            ...s.cash,
            balance: s.cash.balance - payment.amount,
            payments: [...s.cash.payments, payment],
          },
        })
      );
    }

    case 'ADD_EXPENSE': {
      const expense = { ...action.payload, id: `e-${Date.now()}` };
      return withEvent(
        state,
        {
          type: 'ثبت هزینه',
          entity: expense.description || 'هزینه',
          before: `${state.cash.balance.toLocaleString('fa-IR')}`,
          after: `${(state.cash.balance - expense.amount).toLocaleString('fa-IR')}`,
          reason: expense.description,
        },
        (s) => ({
          ...s,
          cash: {
            ...s.cash,
            balance: s.cash.balance - expense.amount,
            expenses: [...s.cash.expenses, expense],
          },
        })
      );
    }

    case 'UPDATE_SETTINGS': {
      return withEvent(
        state,
        {
          type: 'تغییر تنظیمات مدیریت',
          entity: action.payload.label || 'تنظیمات کسب‌وکار',
          before: '—',
          after: '—',
          reason: 'تغییر پارامتر توسط مدیر — کل سامانه بازمحاسبه شد',
        },
        (s) => ({ ...s, settings: { ...s.settings, ...action.payload.patch } })
      );
    }

    case 'UPDATE_PRODUCT_SETTINGS': {
      const { productId, patch } = action.payload;
      return withEvent(
        state,
        {
          type: 'تغییر مشخصات محصول',
          entity: state.products.find((p) => p.id === productId)?.name || productId,
          before: '—',
          after: '—',
          reason: 'تغییر مشخصات محصول توسط مدیر',
        },
        (s) => ({
          ...s,
          products: s.products.map((p) => (p.id === productId ? { ...p, ...patch } : p)),
        })
      );
    }

    default:
      return state;
  }
}

// برای مصرف مستقیم (نمایش ساعات نصب لازم بدون نیاز به state کامل)
export { computeInstallHours };
