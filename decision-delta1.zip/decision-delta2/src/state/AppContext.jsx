import React, { createContext, useContext, useMemo, useReducer } from 'react';
import { appReducer } from './reducer.js';
import { createInitialState } from './initialData.js';
import { computeAlerts } from '../logic/calc.js';

const AppStateContext = createContext(null);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, undefined, createInitialState);

  // بازمحاسبه هشدارها با هر تغییر state — همیشه به‌روز، بدون نیاز به Refresh دستی
  const alerts = useMemo(() => computeAlerts(state), [state]);

  const value = useMemo(() => ({ state, dispatch, alerts }), [state, alerts]);

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useApp باید داخل AppProvider استفاده شود');
  return ctx;
}
