// این فایل فقط «داده نمونه اولیه» چالش است، نه قواعد کسب‌وکار.
// همه قواعد و آستانه‌ها در settings هستند و از پنل مدیریت (صفحه ۳) قابل تغییرند.

function isoOffset(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function createInitialState() {
  return {
    products: [
      { id: 'p100', name: 'محصول ۱۰۰', basePrice: 1250, unitCost: 760, safetyStock: 10, installMinutesPerUnit: 25 },
      { id: 'p200', name: 'محصول ۲۰۰', basePrice: 2100, unitCost: 1390, safetyStock: 8, installMinutesPerUnit: 50 },
      { id: 'p300', name: 'محصول ۳۰۰', basePrice: 3700, unitCost: 2680, safetyStock: 5, installMinutesPerUnit: 90 },
    ],

    inventory: {
      p100: { available: 34 },
      p200: { available: 27 },
      p300: { available: 11 },
    },

    customers: [
      { id: 'c1', name: 'شرکت آروین صنعت' },
      { id: 'c2', name: 'فروشگاه‌های زنجیره‌ای بهار' },
      { id: 'c3', name: 'گروه صنعتی الوند' },
      { id: 'c4', name: 'شرکت پویا تجارت' },
      { id: 'c5', name: 'مجتمع تولیدی کاسپین' },
    ],

    opportunities: [
      { id: 'o1', customerId: 'c1', productId: 'p100', quantity: 20, unitPrice: 1250, discountPercent: 0, dueDate: isoOffset(5), stage: 'جدید' },
      { id: 'o2', customerId: 'c2', productId: 'p200', quantity: 10, unitPrice: 2000, discountPercent: 4.76, dueDate: isoOffset(3), stage: 'پیشنهاد ارسال‌شده' },
      { id: 'o3', customerId: 'c3', productId: 'p300', quantity: 6, unitPrice: 3700, discountPercent: 0, dueDate: isoOffset(10), stage: 'جدید' },
      { id: 'o4', customerId: 'c4', productId: 'p100', quantity: 40, unitPrice: 1187.5, discountPercent: 5, dueDate: isoOffset(2), stage: 'پیشنهاد ارسال‌شده' },
      { id: 'o5', customerId: 'c5', productId: 'p200', quantity: 5, unitPrice: 2100, discountPercent: 0, dueDate: isoOffset(7), stage: 'جدید' },
    ],

    // سفارش‌های قطعی اولیه (تعهد سازمان) — موجودی جدول بالا ("موجودی آزاد") از قبل خالص این سفارش‌هاست.
    orders: [
      { id: 'ord1', customerId: 'c1', productId: 'p100', quantity: 15, unitPrice: 1250, confirmedAt: isoOffset(-4), sourceOpportunityId: null },
      { id: 'ord2', customerId: 'c3', productId: 'p300', quantity: 3, unitPrice: 3700, confirmedAt: isoOffset(-2), sourceOpportunityId: null },
      { id: 'ord3', customerId: 'c2', productId: 'p200', quantity: 8, unitPrice: 2100, confirmedAt: isoOffset(-1), sourceOpportunityId: null },
    ],

    capacity: {
      totalHours: 120,
    },

    cash: {
      balance: 85000,
      receipts: [
        { id: 'r1', amount: 25000, date: isoOffset(1) },
        { id: 'r2', amount: 18000, date: isoOffset(4) },
      ],
      payments: [
        { id: 'pay1', amount: 15000, date: isoOffset(2) },
        { id: 'pay2', amount: 22000, date: isoOffset(6) },
      ],
      expenses: [
        { id: 'e1', amount: 6000, date: isoOffset(-1), description: 'اجاره انبار' },
      ],
    },

    settings: {
      targetMarginPercent: 20,
      minOperatingCash: 40000,
      shippingFlatFee: 150,
      shippingPerUnitFee: 12,
      capacityThresholds: { info: 70, warning: 85, critical: 100 },
      inventoryAlertsEnabled: true,
      capacityAlertsEnabled: true,
      cashAlertsEnabled: true,
    },

    events: [],
  };
}
