import React, { useState } from 'react';
import { useApp } from './state/AppContext.jsx';
import Page1RecordAndAnalyze from './pages/Page1RecordAndAnalyze.jsx';
import Page2Management from './pages/Page2Management.jsx';
import Page3AdminSettings from './pages/Page3AdminSettings.jsx';
import Page4Events from './pages/Page4Events.jsx';

const PAGES = [
  { id: 'record', label: 'ثبت و تحلیل', component: Page1RecordAndAnalyze },
  { id: 'management', label: 'مدیریت', component: Page2Management },
  { id: 'settings', label: 'تنظیمات مدیریت', component: Page3AdminSettings },
  { id: 'events', label: 'رخدادها', component: Page4Events },
];

export default function App() {
  const [pageId, setPageId] = useState('record');
  const { alerts } = useApp();
  const criticalCount = alerts.filter((a) => a.severity === 'بحرانی').length;

  const ActivePage = PAGES.find((p) => p.id === pageId).component;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-title">تصمیم‌دلتا</div>
          <div className="brand-sub">تحلیل زنده اثرات تصمیمات کسب‌وکار</div>
        </div>
        <nav className="nav">
          {PAGES.map((p) => (
            <button
              key={p.id}
              className={`nav-item ${pageId === p.id ? 'active' : ''}`}
              onClick={() => setPageId(p.id)}
            >
              {p.label}
              {p.id === 'management' && criticalCount > 0 ? ` (${criticalCount})` : ''}
            </button>
          ))}
        </nav>
      </aside>
      <main className="main">
        <ActivePage />
      </main>
    </div>
  );
}
