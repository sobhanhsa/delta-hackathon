import React from 'react';

function formatNumber(n) {
  if (typeof n !== 'number' || Number.isNaN(n)) return n;
  return Math.round(n * 100) / 100 === n ? n.toLocaleString('fa-IR') : n.toLocaleString('fa-IR', { maximumFractionDigits: 2 });
}

// rows: [{ label, value, note, tone: 'up' | 'down' | null }]
export default function LiveEffectPanel({ title = 'اثر زنده', rows }) {
  return (
    <div className="live-panel">
      <div className="live-panel-title">{title}</div>
      {rows.map((row) => (
        <div className="live-row" key={row.label}>
          <span>{row.label}</span>
          <span className={row.tone === 'up' ? 'delta-up' : row.tone === 'down' ? 'delta-down' : ''}>
            {typeof row.value === 'number' ? formatNumber(row.value) : row.value}
            {row.note ? <span className="hint"> {row.note}</span> : null}
          </span>
        </div>
      ))}
    </div>
  );
}
