import React, { useMemo, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { computeCashForecast } from '../logic/calc.js';
import LiveEffectPanel from './LiveEffectPanel.jsx';

export default function FinanceSection() {
  const { state, dispatch } = useApp();
  const forecast = useMemo(() => computeCashForecast(state, 7), [state]);
  const isShortage = forecast.minBalance < state.settings.minOperatingCash;

  return (
    <div className="section">
      <h3 className="section-title">مالی</h3>
      <div className="grid-two">
        <div>
          <ReceiptForm dispatch={dispatch} balance={state.cash.balance} />
          <PaymentForm dispatch={dispatch} balance={state.cash.balance} />
          <ExpenseForm dispatch={dispatch} balance={state.cash.balance} />
        </div>
        <div className="card">
          <div className="live-panel-title" style={{ color: 'var(--ink)' }}>وضعیت نقدینگی زنده (۷ روز آینده)</div>
          <div className="live-row">
            <span>موجودی نقد فعلی</span>
            <span>{Math.round(state.cash.balance).toLocaleString('fa-IR')}</span>
          </div>
          <div className="live-row">
            <span>دریافت‌های ۷ روز آینده</span>
            <span>{forecast.upcomingReceipts.reduce((s, r) => s + r.amount, 0).toLocaleString('fa-IR')}</span>
          </div>
          <div className="live-row">
            <span>پرداخت‌های ۷ روز آینده</span>
            <span>{forecast.upcomingPayments.reduce((s, p) => s + p.amount, 0).toLocaleString('fa-IR')}</span>
          </div>
          <div className="live-row">
            <span>کمترین مانده نقد پیش‌بینی‌شده</span>
            <span className={isShortage ? 'delta-down' : ''}>
              {Math.round(forecast.minBalance).toLocaleString('fa-IR')} ({forecast.minBalanceDate})
            </span>
          </div>
          <div className="live-row">
            <span>هشدار کسری نقد</span>
            <span className={isShortage ? 'delta-down' : 'delta-up'}>{isShortage ? 'بله — بحرانی' : 'خیر'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function ReceiptForm({ dispatch, balance }) {
  const [form, setForm] = useState({ amount: '', date: '' });
  const amountNum = form.amount === '' ? null : Number(form.amount);
  const isValid = amountNum > 0 && form.date;

  function handleSubmit(e) {
    e.preventDefault();
    if (!isValid) return;
    dispatch({ type: 'ADD_RECEIPT', payload: { amount: amountNum, date: form.date } });
    setForm({ amount: '', date: '' });
  }

  return (
    <form className="card" onSubmit={handleSubmit} style={{ marginBottom: 14 }}>
      <div className="field-row">
        <div className="field">
          <label>دریافت — مبلغ</label>
          <input type="number" min="0" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
        </div>
        <div className="field">
          <label>تاریخ</label>
          <input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
        </div>
      </div>
      {amountNum > 0 && (
        <p className="hint">
          مانده نقد پس از ثبت: {Math.round(balance + amountNum).toLocaleString('fa-IR')}
        </p>
      )}
      <button className="btn btn-primary" type="submit" disabled={!isValid}>
        ثبت دریافت
      </button>
    </form>
  );
}

function PaymentForm({ dispatch, balance }) {
  const [form, setForm] = useState({ amount: '', date: '' });
  const amountNum = form.amount === '' ? null : Number(form.amount);
  const isValid = amountNum > 0 && form.date;

  function handleSubmit(e) {
    e.preventDefault();
    if (!isValid) return;
    dispatch({ type: 'ADD_PAYMENT', payload: { amount: amountNum, date: form.date } });
    setForm({ amount: '', date: '' });
  }

  return (
    <form className="card" onSubmit={handleSubmit} style={{ marginBottom: 14 }}>
      <div className="field-row">
        <div className="field">
          <label>پرداخت — مبلغ</label>
          <input type="number" min="0" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
        </div>
        <div className="field">
          <label>تاریخ</label>
          <input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
        </div>
      </div>
      {amountNum > 0 && (
        <p className="hint" style={{ color: balance - amountNum < 0 ? 'var(--critical)' : undefined }}>
          مانده نقد پس از ثبت: {Math.round(balance - amountNum).toLocaleString('fa-IR')}
        </p>
      )}
      <button className="btn btn-primary" type="submit" disabled={!isValid}>
        ثبت پرداخت
      </button>
    </form>
  );
}

function ExpenseForm({ dispatch, balance }) {
  const [form, setForm] = useState({ amount: '', date: '', description: '' });
  const amountNum = form.amount === '' ? null : Number(form.amount);
  const isValid = amountNum > 0 && form.date && form.description.trim();

  function handleSubmit(e) {
    e.preventDefault();
    if (!isValid) return;
    dispatch({ type: 'ADD_EXPENSE', payload: { amount: amountNum, date: form.date, description: form.description } });
    setForm({ amount: '', date: '', description: '' });
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      <div className="field-row">
        <div className="field">
          <label>هزینه — مبلغ</label>
          <input type="number" min="0" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
        </div>
        <div className="field">
          <label>تاریخ</label>
          <input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
        </div>
      </div>
      <div className="field">
        <label>توضیح</label>
        <input type="text" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
      </div>
      {amountNum > 0 && (
        <p className="hint" style={{ color: balance - amountNum < 0 ? 'var(--critical)' : undefined }}>
          مانده نقد پس از ثبت: {Math.round(balance - amountNum).toLocaleString('fa-IR')}
        </p>
      )}
      <button className="btn btn-primary" type="submit" disabled={!isValid}>
        ثبت هزینه
      </button>
    </form>
  );
}
