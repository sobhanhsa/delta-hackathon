import React, { useMemo, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { getUsedCapacityHours } from '../logic/calc.js';
import LiveEffectPanel from './LiveEffectPanel.jsx';

export default function OpsSection() {
  const { state, dispatch } = useApp();

  return (
    <div className="section">
      <h3 className="section-title">عملیات</h3>
      <div className="grid-two">
        <InventoryAdjustForm state={state} dispatch={dispatch} />
        <CapacityAdjustForm state={state} dispatch={dispatch} />
      </div>
    </div>
  );
}

function InventoryAdjustForm({ state, dispatch }) {
  const [form, setForm] = useState({ productId: state.products[0]?.id || '', newValue: '', reason: '' });
  const product = state.products.find((p) => p.id === form.productId);
  const currentAvailable = state.inventory[form.productId]?.available ?? 0;
  const newValueNum = form.newValue === '' ? null : Number(form.newValue);

  const affectedOpportunities = useMemo(() => {
    if (newValueNum === null) return [];
    return state.opportunities.filter(
      (o) => o.productId === form.productId && o.stage !== 'قطعی‌شده' && o.stage !== 'از دست‌رفته' && o.quantity > newValueNum
    );
  }, [state.opportunities, form.productId, newValueNum]);

  const isValid = form.productId && newValueNum !== null && !Number.isNaN(newValueNum) && form.reason.trim();

  function handleSubmit(e) {
    e.preventDefault();
    if (!isValid) return;
    dispatch({ type: 'ADJUST_INVENTORY', payload: { productId: form.productId, newValue: newValueNum, reason: form.reason } });
    setForm({ productId: form.productId, newValue: '', reason: '' });
  }

  return (
    <div>
      <form className="card" onSubmit={handleSubmit} style={{ marginBottom: 14 }}>
        <div className="field">
          <label>اصلاح موجودی — محصول</label>
          <select value={form.productId} onChange={(e) => setForm((f) => ({ ...f, productId: e.target.value }))}>
            {state.products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>موجودی جدید</label>
          <input type="number" value={form.newValue} onChange={(e) => setForm((f) => ({ ...f, newValue: e.target.value }))} />
        </div>
        <div className="field">
          <label>دلیل</label>
          <input type="text" value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} />
        </div>
        <button className="btn btn-primary" type="submit" disabled={!isValid}>
          ثبت اصلاح موجودی
        </button>
      </form>

      {newValueNum !== null && !Number.isNaN(newValueNum) && (
        <LiveEffectPanel
          title="اثر زنده — اصلاح موجودی"
          rows={[
            { label: 'موجودی فعلی', value: currentAvailable },
            { label: 'موجودی پس از ثبت', value: newValueNum, tone: newValueNum < currentAvailable ? 'down' : 'up' },
            {
              label: 'فرصت‌های متاثر',
              value: affectedOpportunities.length ? `${affectedOpportunities.length} فرصت غیرقابل انجام می‌شوند` : 'بدون تاثیر',
              tone: affectedOpportunities.length ? 'down' : undefined,
            },
          ]}
        />
      )}
    </div>
  );
}

function CapacityAdjustForm({ state, dispatch }) {
  const [form, setForm] = useState({ date: '', availableHours: '', reason: '' });
  const usedHours = getUsedCapacityHours(state);
  const currentTotal = state.capacity.totalHours;
  const newTotalNum = form.availableHours === '' ? null : Number(form.availableHours);

  const isValid = newTotalNum !== null && !Number.isNaN(newTotalNum) && form.date && form.reason.trim();

  function handleSubmit(e) {
    e.preventDefault();
    if (!isValid) return;
    dispatch({ type: 'ADJUST_CAPACITY', payload: { availableHours: newTotalNum, reason: `${form.reason} (تاریخ: ${form.date})` } });
    setForm({ date: '', availableHours: '', reason: '' });
  }

  const newRemaining = newTotalNum !== null ? newTotalNum - usedHours : null;
  const newUsagePercent = newTotalNum ? (usedHours / newTotalNum) * 100 : 0;

  return (
    <div>
      <form className="card" onSubmit={handleSubmit} style={{ marginBottom: 14 }}>
        <div className="field">
          <label>اصلاح ظرفیت نصب — تاریخ</label>
          <input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
        </div>
        <div className="field">
          <label>ساعات قابل استفاده (کل ظرفیت جدید)</label>
          <input
            type="number"
            value={form.availableHours}
            onChange={(e) => setForm((f) => ({ ...f, availableHours: e.target.value }))}
          />
        </div>
        <div className="field">
          <label>دلیل</label>
          <input type="text" value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} />
        </div>
        <button className="btn btn-primary" type="submit" disabled={!isValid}>
          ثبت اصلاح ظرفیت
        </button>
      </form>

      {newTotalNum !== null && !Number.isNaN(newTotalNum) && (
        <LiveEffectPanel
          title="اثر زنده — اصلاح ظرفیت نصب"
          rows={[
            { label: 'ظرفیت فعلی', value: `${currentTotal} ساعت` },
            { label: 'مصرف‌شده (سفارش‌های قطعی)', value: `${Math.round(usedHours * 10) / 10} ساعت` },
            { label: 'ظرفیت باقی‌مانده پس از ثبت', value: `${Math.round(newRemaining * 10) / 10} ساعت`, tone: newRemaining < 0 ? 'down' : 'up' },
            { label: 'درصد مصرف پس از ثبت', value: `${Math.round(newUsagePercent)}٪`, tone: newUsagePercent >= state.settings.capacityThresholds.warning ? 'down' : undefined },
          ]}
        />
      )}
    </div>
  );
}
