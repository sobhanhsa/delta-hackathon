import React, { useMemo, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { priceFromDiscount, discountFromPrice, feasibilityToAlertSeverity } from '../logic/calc.js';
import { evaluateOpportunity } from '../logic/evaluateOpportunity.js';
import { FeasibilityBadge, SeverityBadge } from './Badge.jsx';
import LiveEffectPanel from './LiveEffectPanel.jsx';

const STAGES = ['جدید', 'پیشنهاد ارسال‌شده', 'قطعی‌شده', 'از دست‌رفته'];

const emptyForm = {
  customerId: '',
  productId: '',
  quantity: '',
  unitPrice: '',
  discountPercent: 0,
  dueDate: '',
};

export default function SalesSection() {
  const { state, dispatch } = useApp();
  const [form, setForm] = useState(emptyForm);

  const selectedProduct = state.products.find((p) => p.id === form.productId);

  function handleProductChange(productId) {
    const product = state.products.find((p) => p.id === productId);
    setForm((f) => ({
      ...f,
      productId,
      unitPrice: product ? product.basePrice : '',
      discountPercent: 0,
    }));
  }

  function handleDiscountChange(discountPercent) {
    if (!selectedProduct) {
      setForm((f) => ({ ...f, discountPercent }));
      return;
    }
    setForm((f) => ({
      ...f,
      discountPercent,
      unitPrice: priceFromDiscount(selectedProduct.basePrice, discountPercent),
    }));
  }

  function handleUnitPriceChange(unitPrice) {
    if (!selectedProduct) {
      setForm((f) => ({ ...f, unitPrice }));
      return;
    }
    setForm((f) => ({
      ...f,
      unitPrice,
      discountPercent: discountFromPrice(selectedProduct.basePrice, unitPrice),
    }));
  }

  const quantityNum = Number(form.quantity);
  const unitPriceNum = Number(form.unitPrice);

  const liveEvaluation = useMemo(() => {
    if (!selectedProduct || !quantityNum || quantityNum <= 0) return null;
    return evaluateOpportunity(
      { quantity: quantityNum, unitPrice: unitPriceNum, productId: form.productId },
      state
    );
  }, [state, selectedProduct, quantityNum, unitPriceNum, form.productId]);

  const isValid =
    form.customerId &&
    form.productId &&
    quantityNum > 0 &&
    unitPriceNum >= 0 &&
    form.discountPercent >= 0 &&
    form.dueDate;

  function handleSubmit(e) {
    e.preventDefault();
    if (!isValid) return;
    dispatch({
      type: 'ADD_OPPORTUNITY',
      payload: {
        customerId: form.customerId,
        productId: form.productId,
        quantity: quantityNum,
        unitPrice: unitPriceNum,
        discountPercent: Number(form.discountPercent),
        dueDate: form.dueDate,
      },
    });
    setForm(emptyForm);
  }

  function handleStageChange(opp, newStage) {
    if (opp.stage === 'قطعی‌شده') return; // بعد از قطعی‌شدن، تعهد ثبت شده و برگشت ندارد
    if (newStage === 'قطعی‌شده') {
      dispatch({ type: 'CONFIRM_OPPORTUNITY', payload: { id: opp.id } });
    } else {
      dispatch({ type: 'UPDATE_OPPORTUNITY', payload: { id: opp.id, patch: { stage: newStage } } });
    }
  }

  return (
    <div className="section">
      <h3 className="section-title">فروش</h3>
      <div className="grid-two">
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>مشتری</th>
                  <th>محصول</th>
                  <th>تعداد</th>
                  <th>مبلغ</th>
                  <th>تخفیف</th>
                  <th>موعد</th>
                  <th>مرحله</th>
                  <th>وضعیت تحلیلی</th>
                  <th>هشدار</th>
                </tr>
              </thead>
              <tbody>
                {state.opportunities.map((opp) => {
                  const customer = state.customers.find((c) => c.id === opp.customerId);
                  const evalResult = evaluateOpportunity(
                    { quantity: opp.quantity, unitPrice: opp.unitPrice, productId: opp.productId, alreadyConfirmed: opp.stage === 'قطعی‌شده' },
                    state
                  );
                  const severity = evalResult ? feasibilityToAlertSeverity(evalResult.status) : null;
                  return (
                    <tr key={opp.id}>
                      <td>{customer?.name}</td>
                      <td>{evalResult?.product.name}</td>
                      <td>{opp.quantity}</td>
                      <td>{evalResult ? Math.round(evalResult.revenue).toLocaleString('fa-IR') : '—'}</td>
                      <td>{opp.discountPercent}٪</td>
                      <td>{opp.dueDate}</td>
                      <td>
                        <select
                          value={opp.stage}
                          disabled={opp.stage === 'قطعی‌شده'}
                          onChange={(e) => handleStageChange(opp, e.target.value)}
                        >
                          {STAGES.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>{evalResult ? <FeasibilityBadge status={evalResult.status} /> : '—'}</td>
                      <td>{severity ? <SeverityBadge severity={severity} /> : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <form className="card" onSubmit={handleSubmit} style={{ marginBottom: 14 }}>
            <div className="field">
              <label>مشتری</label>
              <select value={form.customerId} onChange={(e) => setForm((f) => ({ ...f, customerId: e.target.value }))}>
                <option value="">انتخاب کنید</option>
                {state.customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>محصول</label>
              <select value={form.productId} onChange={(e) => handleProductChange(e.target.value)}>
                <option value="">انتخاب کنید</option>
                {state.products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="field-row">
              <div className="field">
                <label>تعداد</label>
                <input
                  type="number"
                  min="0"
                  value={form.quantity}
                  onChange={(e) => setForm((f) => ({ ...f, quantity: e.target.value }))}
                />
              </div>
              <div className="field">
                <label>قیمت واحد</label>
                <input
                  type="number"
                  min="0"
                  value={form.unitPrice}
                  onChange={(e) => handleUnitPriceChange(Number(e.target.value))}
                />
              </div>
            </div>
            <div className="field-row">
              <div className="field">
                <label>درصد تخفیف</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={form.discountPercent}
                  onChange={(e) => handleDiscountChange(Number(e.target.value))}
                />
              </div>
              <div className="field">
                <label>موعد تحویل</label>
                <input
                  type="date"
                  value={form.dueDate}
                  onChange={(e) => setForm((f) => ({ ...f, dueDate: e.target.value }))}
                />
              </div>
            </div>
            <button className="btn btn-primary" type="submit" disabled={!isValid}>
              ثبت فرصت فروش
            </button>
          </form>

          {liveEvaluation && (
            <LiveEffectPanel
              rows={[
                { label: 'درآمد', value: liveEvaluation.revenue },
                { label: 'سود عملیاتی', value: liveEvaluation.profit, tone: liveEvaluation.profit >= 0 ? 'up' : 'down' },
                { label: 'حاشیه سود', value: `${Math.round(liveEvaluation.margin)}٪` },
                { label: 'ساعت نصب موردنیاز', value: liveEvaluation.installHours },
                {
                  label: 'موجودی پس از این فروش',
                  value: liveEvaluation.remainingInventoryAfter,
                  tone: liveEvaluation.remainingInventoryAfter < 0 ? 'down' : undefined,
                },
                {
                  label: 'ظرفیت باقی‌مانده پس از این فروش',
                  value: `${Math.round(liveEvaluation.remainingCapacityAfter * 10) / 10} ساعت`,
                  tone: liveEvaluation.remainingCapacityAfter < 0 ? 'down' : undefined,
                },
                { label: 'وضعیت امکان انجام', value: liveEvaluation.status },
              ]}
            />
          )}
        </div>
      </div>
    </div>
  );
}
