import React from 'react';

const FEASIBILITY_CLASS = {
  'قابل انجام': 'badge-feasible',
  'مشروط': 'badge-conditional',
  'غیرقابل انجام در شرایط فعلی': 'badge-infeasible',
};

const SEVERITY_CLASS = {
  'اطلاع': 'badge-info',
  'خطر': 'badge-warning',
  'بحرانی': 'badge-critical',
};

export function FeasibilityBadge({ status }) {
  return <span className={`badge ${FEASIBILITY_CLASS[status] || 'badge-info'}`}>{status}</span>;
}

export function SeverityBadge({ severity }) {
  if (!severity) return null;
  return <span className={`badge ${SEVERITY_CLASS[severity] || 'badge-info'}`}>{severity}</span>;
}
