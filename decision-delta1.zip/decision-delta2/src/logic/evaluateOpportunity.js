import { evaluateDeal, computeFeasibilityStatus, getRemainingCapacityHours } from './calc.js';

// ارزیابی کامل یک فرصت فروش (چه فرضی/در حال تایپ، چه واقعی در فهرست)
// نسبت به موجودی و ظرفیت «فعلی» سامانه.
export function evaluateOpportunity({ quantity, unitPrice, productId, alreadyConfirmed = false }, state) {
  const product = state.products.find((p) => p.id === productId);
  if (!product) return null;

  const deal = evaluateDeal({ quantity, unitPrice, product, settings: state.settings });
  const availableNow = state.inventory[productId]?.available ?? 0;
  const remainingCapacityNow = getRemainingCapacityHours(state);

  // اگر این فرصت از قبل قطعی شده، اثرش از قبل در موجودی/ظرفیت فعلی لحاظ شده؛
  // در غیر این صورت باید فرضی کم شود تا وضعیت امکان انجام محاسبه شود.
  const remainingInventoryAfter = alreadyConfirmed ? availableNow : availableNow - quantity;
  const remainingCapacityAfter = alreadyConfirmed ? remainingCapacityNow : remainingCapacityNow - deal.installHours;

  const status = computeFeasibilityStatus({
    remainingInventoryAfter,
    remainingCapacityAfter,
    margin: deal.margin,
    settings: state.settings,
  });

  return { ...deal, status, remainingInventoryAfter, remainingCapacityAfter, availableNow, remainingCapacityNow, product };
}
