// موتور محاسبه: فقط توابع خالص. هیچ عدد کسب‌وکاری اینجا ثابت نوشته نشده؛
// هر مقدار موثر بر نتیجه (حاشیه سود هدف، هزینه ارسال، آستانه‌ها و ...) از settings خوانده می‌شود.

export function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function priceFromDiscount(basePrice, discountPercent) {
  return round2(basePrice * (1 - discountPercent / 100));
}

export function discountFromPrice(basePrice, unitPrice) {
  if (!basePrice) return 0;
  return round2((1 - unitPrice / basePrice) * 100);
}

export function computeRevenue(quantity, unitPrice) {
  return quantity * unitPrice;
}

export function computeCogs(quantity, unitCost) {
  return quantity * unitCost;
}

export function computeShipping(quantity, settings) {
  return settings.shippingFlatFee + settings.shippingPerUnitFee * quantity;
}

export function computeInstallHours(quantity, installMinutesPerUnit) {
  return (quantity * installMinutesPerUnit) / 60;
}

export function computeProfit(revenue, cogs, shipping) {
  return revenue - cogs - shipping;
}

export function computeMargin(profit, revenue) {
  if (!revenue) return 0;
  return (profit / revenue) * 100;
}

// جمع ساعات نصب مصرف‌شده توسط همه سفارش‌های قطعی فعلی
export function getUsedCapacityHours(state) {
  return state.orders.reduce((sum, order) => {
    const product = state.products.find((p) => p.id === order.productId);
    if (!product) return sum;
    return sum + computeInstallHours(order.quantity, product.installMinutesPerUnit);
  }, 0);
}

export function getRemainingCapacityHours(state) {
  return state.capacity.totalHours - getUsedCapacityHours(state);
}

export function getCapacityUsagePercent(state) {
  if (!state.capacity.totalHours) return 0;
  return (getUsedCapacityHours(state) / state.capacity.totalHours) * 100;
}

// محاسبه کامل یک معامله (فرصت یا سفارش) بر اساس تعداد/قیمت/تخفیف داده‌شده
export function evaluateDeal({ quantity, unitPrice, product, settings }) {
  const revenue = computeRevenue(quantity, unitPrice);
  const cogs = computeCogs(quantity, product.unitCost);
  const shipping = computeShipping(quantity, settings);
  const profit = computeProfit(revenue, cogs, shipping);
  const margin = computeMargin(profit, revenue);
  const installHours = computeInstallHours(quantity, product.installMinutesPerUnit);
  return { revenue, cogs, shipping, profit, margin, installHours };
}

// وضعیت تحلیلی یک فرصت/سفارش: قابل انجام / مشروط / غیرقابل انجام در شرایط فعلی
export function computeFeasibilityStatus({ remainingInventoryAfter, remainingCapacityAfter, margin, settings }) {
  if (remainingInventoryAfter < 0 || remainingCapacityAfter < 0) {
    return 'غیرقابل انجام در شرایط فعلی';
  }
  if (margin < settings.targetMarginPercent) {
    return 'مشروط';
  }
  return 'قابل انجام';
}

export function feasibilityToAlertSeverity(status) {
  if (status === 'غیرقابل انجام در شرایط فعلی') return 'بحرانی';
  if (status === 'مشروط') return 'خطر';
  return null;
}

// موجودی: شدت هشدار بر اساس موجودی آزاد نسبت به موجودی ایمن
export function getInventorySeverity(available, safetyStock) {
  if (available < 0) return 'بحرانی';
  if (available < safetyStock) return 'خطر';
  if (available < safetyStock * 1.5) return 'اطلاع';
  return null;
}

// ظرفیت: شدت هشدار بر اساس درصد مصرف نسبت به آستانه‌های تنظیمات
export function getCapacitySeverity(usagePercent, thresholds) {
  if (usagePercent >= thresholds.critical) return 'بحرانی';
  if (usagePercent >= thresholds.warning) return 'خطر';
  if (usagePercent >= thresholds.info) return 'اطلاع';
  return null;
}

// موتور مرکزی هشدارها: از state فعلی، تمام هشدارهای فعال را می‌سازد
export function computeAlerts(state) {
  const alerts = [];
  const { settings } = state;

  if (settings.inventoryAlertsEnabled) {
    state.products.forEach((product) => {
      const available = state.inventory[product.id]?.available ?? 0;
      const severity = getInventorySeverity(available, product.safetyStock);
      if (severity) {
        const deficit = product.safetyStock - available;
        alerts.push({
          id: `inv-${product.id}`,
          title: `${severity === 'بحرانی' ? 'بحرانی' : severity === 'خطر' ? 'خطر' : 'اطلاع'} — موجودی ${product.name}`,
          severity,
          category: 'موجودی',
          reason: `موجودی آزاد (${available}) ${available < 0 ? 'منفی شده و' : 'به آستانه موجودی ایمن نزدیک شده و'} کمتر از موجودی ایمن (${product.safetyStock}) است.`,
          effect: available < 0
            ? `کسری ${Math.abs(available)} واحد نسبت به تقاضای ثبت‌شده.`
            : `فاصله ${Math.max(deficit, 0)} واحد تا موجودی ایمن.`,
          suggestion: 'کاهش تعداد فروش جدید، تغییر موعد تحویل یا اصلاح موجودی از بخش عملیات.',
        });
      }
    });
  }

  if (settings.capacityAlertsEnabled) {
    const usagePercent = getCapacityUsagePercent(state);
    const severity = getCapacitySeverity(usagePercent, settings.capacityThresholds);
    if (severity) {
      alerts.push({
        id: 'capacity',
        title: `${severity} — مصرف ظرفیت نصب`,
        severity,
        category: 'ظرفیت',
        reason: `مصرف ظرفیت نصب به ${round2(usagePercent)}٪ رسیده که از آستانه ${severity} (${settings.capacityThresholds[severity === 'بحرانی' ? 'critical' : severity === 'خطر' ? 'warning' : 'info']}٪) عبور کرده است.`,
        effect: `ظرفیت باقی‌مانده: ${round2(getRemainingCapacityHours(state))} ساعت از ${state.capacity.totalHours} ساعت کل.`,
        suggestion: 'افزایش ظرفیت نصب یا تغییر موعد سفارش‌های در صف.',
      });
    }
  }

  if (settings.cashAlertsEnabled) {
    const forecast = computeCashForecast(state, 7);
    if (forecast.minBalance < settings.minOperatingCash) {
      alerts.push({
        id: 'cash',
        title: 'بحرانی — کسری نقدینگی پیش‌بینی‌شده',
        severity: 'بحرانی',
        category: 'مالی',
        reason: `کمترین مانده نقد پیش‌بینی‌شده طی ۷ روز آینده (${Math.round(forecast.minBalance).toLocaleString('fa-IR')}) کمتر از حداقل نقد عملیاتی (${settings.minOperatingCash.toLocaleString('fa-IR')}) است.`,
        effect: `در تاریخ ${forecast.minBalanceDate} مانده نقد به کمترین سطح می‌رسد.`,
        suggestion: 'تسریع در وصول مطالبات یا تعویق پرداخت‌های غیرضروری.',
      });
    }
  }

  return alerts;
}

// پیش‌بینی نقدینگی N روز آینده بر اساس دریافت‌ها و پرداخت‌های ثبت‌شده
export function computeCashForecast(state, days = 7) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const timeline = [];
  for (let i = 0; i <= days; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() + i);
    timeline.push(d.toISOString().slice(0, 10));
  }

  let running = state.cash.balance;
  let minBalance = running;
  let minBalanceDate = timeline[0];
  const upcomingReceipts = [];
  const upcomingPayments = [];

  timeline.forEach((date, idx) => {
    if (idx === 0) return; // امروز، قبل از هر تغییری
    const receiptsToday = state.cash.receipts.filter((r) => r.date === date);
    const paymentsToday = state.cash.payments.filter((p) => p.date === date);
    receiptsToday.forEach((r) => upcomingReceipts.push(r));
    paymentsToday.forEach((p) => upcomingPayments.push(p));
    running += receiptsToday.reduce((s, r) => s + r.amount, 0);
    running -= paymentsToday.reduce((s, p) => s + p.amount, 0);
    if (running < minBalance) {
      minBalance = running;
      minBalanceDate = date;
    }
  });

  return {
    currentBalance: state.cash.balance,
    projectedBalance: running,
    minBalance,
    minBalanceDate,
    upcomingReceipts,
    upcomingPayments,
  };
}
