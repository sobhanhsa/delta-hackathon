import React, { useRef, useState } from 'react';
import { useApp } from '../state/AppContext.jsx';

const PRODUCT_FIELDS = ['basePrice', 'unitCost', 'safetyStock', 'installMinutesPerUnit'];
const SETTINGS_FIELDS = [
  'targetMarginPercent',
  'minOperatingCash',
  'shippingFlatFee',
  'shippingPerUnitFee',
  'capacityThresholds',
  'inventoryAlertsEnabled',
  'capacityAlertsEnabled',
  'cashAlertsEnabled',
];

// عکس‌برداری از مقادیر قابل‌ویرایش این صفحه — مبنای مقایسه برای تشخیص تغییرات ذخیره‌نشده
function buildDraft(state) {
  return {
    products: state.products.map((p) => ({
      id: p.id,
      basePrice: p.basePrice,
      unitCost: p.unitCost,
      safetyStock: p.safetyStock,
      installMinutesPerUnit: p.installMinutesPerUnit,
    })),
    settings: SETTINGS_FIELDS.reduce((acc, key) => {
      acc[key] =
        key === 'capacityThresholds' ? { ...state.settings.capacityThresholds } : state.settings[key];
      return acc;
    }, {}),
    capacityTotalHours: state.capacity.totalHours,
  };
}

// در این پروژه بک‌اندی وجود ندارد؛ این تابع فقط رفتار یک درخواست شبکه‌ای واقعی برای ذخیره تنظیمات را شبیه‌سازی می‌کند
function sendSettingsToServer(payload) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ ok: true }), 500);
  });
}

// فیلد عددی با commit روی onBlur تا هر ضربه کلید یک به‌روزرسانی جداگانه ثبت نکند
function CommitNumberField({ label, value, onCommit }) {
  const [local, setLocal] = useState(value);

  return (
    <div className="field">
      <label>{label}</label>
      <input
        type="number"
        value={local}
        onChange={(e) => setLocal(e.target.value)}
        onFocus={() => setLocal(value)}
        onBlur={() => {
          const num = Number(local);
          if (!Number.isNaN(num) && num !== value) onCommit(num);
        }}
      />
    </div>
  );
}

export default function Page3AdminSettings() {
  const { state, dispatch } = useApp();
  const [draft, setDraft] = useState(() => buildDraft(state));
  const baselineRef = useRef(buildDraft(state));
  const [saving, setSaving] = useState(false);

  const isDirty = JSON.stringify(draft) !== JSON.stringify(baselineRef.current);

  function patchProduct(productId, patch) {
    setDraft((d) => ({
      ...d,
      products: d.products.map((p) => (p.id === productId ? { ...p, ...patch } : p)),
    }));
  }

  function patchSettings(patch) {
    setDraft((d) => ({ ...d, settings: { ...d.settings, ...patch } }));
  }

  function setCapacityTotalHours(value) {
    setDraft((d) => ({ ...d, capacityTotalHours: value }));
  }

  async function handleSave() {
    if (!isDirty || saving) return;
    const baseline = baselineRef.current;
    setSaving(true);
    try {
      await sendSettingsToServer(draft);

      draft.products.forEach((p) => {
        const before = baseline.products.find((bp) => bp.id === p.id);
        const patch = {};
        PRODUCT_FIELDS.forEach((field) => {
          if (before[field] !== p[field]) patch[field] = p[field];
        });
        if (Object.keys(patch).length > 0) {
          dispatch({ type: 'UPDATE_PRODUCT_SETTINGS', payload: { productId: p.id, patch } });
        }
      });

      const settingsPatch = {};
      SETTINGS_FIELDS.forEach((key) => {
        if (JSON.stringify(draft.settings[key]) !== JSON.stringify(baseline.settings[key])) {
          settingsPatch[key] = draft.settings[key];
        }
      });
      if (Object.keys(settingsPatch).length > 0) {
        dispatch({ type: 'UPDATE_SETTINGS', payload: { label: 'تنظیمات مدیریت', patch: settingsPatch } });
      }

      if (draft.capacityTotalHours !== baseline.capacityTotalHours) {
        dispatch({
          type: 'ADJUST_CAPACITY',
          payload: { availableHours: draft.capacityTotalHours, reason: 'تغییر ظرفیت پایه از پنل تنظیمات' },
        });
      }

      baselineRef.current = draft;
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <header className="page-header page-header--with-actions">
        <div>
          <h1 className="page-title">صفحه ۳ — تنظیمات مدیریت</h1>
          <p className="page-desc">
            تغییرات این صفحه فقط پس از زدن «ذخیره تغییرات» روی سامانه اعمال و برای سرور ارسال می‌شود.
          </p>
        </div>
        <div className="page-header-actions">
          {isDirty && !saving && <span className="unsaved-note">تغییرات ذخیره‌نشده</span>}
          <button className="btn btn-primary" disabled={!isDirty || saving} onClick={handleSave}>
            {saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
          </button>
        </div>
      </header>

      <div className="section">
        <h3 className="section-title">مشخصات محصولات</h3>
        <div className="card">
          {draft.products.map((p) => {
            const productName = state.products.find((sp) => sp.id === p.id)?.name || p.id;
            return (
              <div key={p.id} style={{ marginBottom: 18, paddingBottom: 14, borderBottom: '1px solid var(--border)' }}>
                <strong>{productName}</strong>
                <div className="field-row" style={{ marginTop: 10 }}>
                  <CommitNumberField
                    label="قیمت پایه"
                    value={p.basePrice}
                    onCommit={(v) => patchProduct(p.id, { basePrice: v })}
                  />
                  <CommitNumberField
                    label="هزینه واحد"
                    value={p.unitCost}
                    onCommit={(v) => patchProduct(p.id, { unitCost: v })}
                  />
                </div>
                <div className="field-row">
                  <CommitNumberField
                    label="موجودی ایمن"
                    value={p.safetyStock}
                    onCommit={(v) => patchProduct(p.id, { safetyStock: v })}
                  />
                  <CommitNumberField
                    label="زمان نصب هر واحد (دقیقه)"
                    value={p.installMinutesPerUnit}
                    onCommit={(v) => patchProduct(p.id, { installMinutesPerUnit: v })}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="section">
        <h3 className="section-title">قواعد مالی</h3>
        <div className="card">
          <div className="field-row">
            <CommitNumberField
              label="حاشیه سود هدف (٪)"
              value={draft.settings.targetMarginPercent}
              onCommit={(v) => patchSettings({ targetMarginPercent: v })}
            />
            <CommitNumberField
              label="حداقل نقد عملیاتی"
              value={draft.settings.minOperatingCash}
              onCommit={(v) => patchSettings({ minOperatingCash: v })}
            />
          </div>
          <div className="field-row">
            <CommitNumberField
              label="هزینه ثابت ارسال"
              value={draft.settings.shippingFlatFee}
              onCommit={(v) => patchSettings({ shippingFlatFee: v })}
            />
            <CommitNumberField
              label="هزینه هر واحد ارسال"
              value={draft.settings.shippingPerUnitFee}
              onCommit={(v) => patchSettings({ shippingPerUnitFee: v })}
            />
          </div>
        </div>
      </div>

      <div className="section">
        <h3 className="section-title">قواعد ظرفیت</h3>
        <div className="card">
          <div className="field-row">
            <CommitNumberField
              label="ظرفیت موجود (ساعت)"
              value={draft.capacityTotalHours}
              onCommit={(v) => setCapacityTotalHours(v)}
            />
          </div>
          <div className="field-row">
            <CommitNumberField
              label="آستانه اطلاع (٪)"
              value={draft.settings.capacityThresholds.info}
              onCommit={(v) =>
                patchSettings({ capacityThresholds: { ...draft.settings.capacityThresholds, info: v } })
              }
            />
            <CommitNumberField
              label="آستانه خطر (٪)"
              value={draft.settings.capacityThresholds.warning}
              onCommit={(v) =>
                patchSettings({ capacityThresholds: { ...draft.settings.capacityThresholds, warning: v } })
              }
            />
          </div>
          <div className="field-row">
            <CommitNumberField
              label="آستانه بحرانی (٪)"
              value={draft.settings.capacityThresholds.critical}
              onCommit={(v) =>
                patchSettings({ capacityThresholds: { ...draft.settings.capacityThresholds, critical: v } })
              }
            />
          </div>
        </div>
      </div>

      <div className="section">
        <h3 className="section-title">فعال یا غیرفعال بودن هشدارها</h3>
        <div className="card">
          <ToggleRow
            label="هشدارهای موجودی"
            checked={draft.settings.inventoryAlertsEnabled}
            onChange={(v) => patchSettings({ inventoryAlertsEnabled: v })}
          />
          <ToggleRow
            label="هشدارهای ظرفیت"
            checked={draft.settings.capacityAlertsEnabled}
            onChange={(v) => patchSettings({ capacityAlertsEnabled: v })}
          />
          <ToggleRow
            label="هشدارهای نقدینگی"
            checked={draft.settings.cashAlertsEnabled}
            onChange={(v) => patchSettings({ cashAlertsEnabled: v })}
          />
        </div>
      </div>
    </>
  );
}

function ToggleRow({ label, checked, onChange }) {
  return (
    <div className="toggle-row">
      <span>{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </div>
  );
}
