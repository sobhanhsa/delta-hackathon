import React from 'react';
import SalesSection from '../components/SalesSection.jsx';
import OpsSection from '../components/OpsSection.jsx';
import FinanceSection from '../components/FinanceSection.jsx';

export default function Page1RecordAndAnalyze() {
  return (
    <>
      <header className="page-header">
        <h1 className="page-title">صفحه ۱ — ثبت و تحلیل</h1>
        <p className="page-desc">
          هر تغییر فیلد پیش از ثبت، اثر آن را به‌صورت زنده در پنل کنار فرم نشان می‌دهد. داده واقعی فقط پس از ثبت تغییر می‌کند.
        </p>
      </header>
      <SalesSection />
      <OpsSection />
      <FinanceSection />
    </>
  );
}
