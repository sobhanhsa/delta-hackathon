import React, { useMemo } from 'react';
import { useApp } from '../state/AppContext.jsx';
import { evaluateDeal, getCapacityUsagePercent, getInventorySeverity } from '../logic/calc.js';
import { SeverityBadge } from '../components/Badge.jsx';

export default function Page2Management() {
  const { state, alerts } = useApp();

  const kpis = useMemo(() => {
    const confirmedRevenue = state.orders.reduce((s, o) => s + o.quantity * o.unitPrice, 0);
    const confirmedProfit = state.orders.reduce((s, o) => {
      const product = state.products.find((p) => p.id === o.productId);
      const deal = evaluateDeal({ quantity: o.quantity, unitPrice: o.unitPrice, product, settings: state.settings });
      return s + deal.profit;
    }, 0);
    const openOpportunities = state.opportunities.filter(
      (o) => o.stage !== 'قطعی‌شده' && o.stage !== 'از دست‌رفته'
    ).length;
    const ordersAtRisk = state.orders.filter((o) => {
      const product = state.products.find((p) => p.id === o.productId);
      const available = state.inventory[o.productId]?.available ?? 0;
      return getInventorySeverity(available, product.safetyStock) === 'بحرانی';
    }).length;
    const criticalAlerts = alerts.filter((a) => a.severity === 'بحرانی').length;
    const capacityUsage = getCapacityUsagePercent(state);

    return { confirmedRevenue, confirmedProfit, openOpportunities, ordersAtRisk, criticalAlerts, capacityUsage };
  }, [state, alerts]);

  return (
    <>
      <header className="page-header">
        <h1 className="page-title">صفحه ۲ — مدیریت</h1>
        <p className="page-desc">وضعیت لحظه‌ای کسب‌وکار — بدون نیاز به بارگذاری مجدد صفحه.</p>
      </header>

      <div className="kpi-grid">
        <KpiCard label="درآمد قطعی" value={Math.round(kpis.confirmedRevenue).toLocaleString('fa-IR')} />
        <KpiCard label="سود عملیاتی" value={Math.round(kpis.confirmedProfit).toLocaleString('fa-IR')} />
        <KpiCard label="موجودی نقد" value={Math.round(state.cash.balance).toLocaleString('fa-IR')} />
        <KpiCard label="فرصت‌های باز" value={kpis.openOpportunities} />
        <KpiCard label="سفارش‌های در خطر" value={kpis.ordersAtRisk} />
        <KpiCard label="هشدارهای بحرانی" value={kpis.criticalAlerts} />
        <KpiCard label="مصرف ظرفیت نصب" value={`${Math.round(kpis.capacityUsage)}٪`} />
        <KpiCard label="تعداد محصولات" value={state.products.length} />
      </div>

      <div className="section">
        <h3 className="section-title">موجودی محصولات</h3>
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>محصول</th>
                  <th>موجودی آزاد</th>
                  <th>موجودی ایمن</th>
                  <th>وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {state.products.map((p) => {
                  const available = state.inventory[p.id]?.available ?? 0;
                  const severity = getInventorySeverity(available, p.safetyStock);
                  return (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td>{available}</td>
                      <td>{p.safetyStock}</td>
                      <td>{severity ? <SeverityBadge severity={severity} /> : 'عادی'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="section">
        <h3 className="section-title">مرکز هشدار</h3>
        {alerts.length === 0 ? (
          <div className="card empty-state">در حال حاضر هشدار فعالی وجود ندارد.</div>
        ) : (
          alerts.map((alert) => (
            <div key={alert.id} className={`alert-card ${alert.severity === 'بحرانی' ? 'critical' : alert.severity === 'خطر' ? 'warning' : 'info'}`}>
              <div className="alert-title">
                <span>{alert.title}</span>
                <SeverityBadge severity={alert.severity} />
              </div>
              <div className="alert-meta">علت: {alert.reason}</div>
              <div className="alert-meta">اثر: {alert.effect}</div>
              <div className="alert-meta">پیشنهاد اصلاح: {alert.suggestion}</div>
            </div>
          ))
        )}
      </div>
    </>
  );
}

function KpiCard({ label, value }) {
  return (
    <div className="kpi-card">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">{value}</div>
    </div>
  );
}
