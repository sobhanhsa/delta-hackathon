import React from 'react';
import { useApp } from '../state/AppContext.jsx';

export default function Page4Events() {
  const { state } = useApp();

  return (
    <>
      <header className="page-header">
        <h1 className="page-title">صفحه ۴ — رخدادها</h1>
        <p className="page-desc">هر ثبت واقعی یک رخداد سازمانی می‌سازد. سوابق هرگز حذف نمی‌شوند.</p>
      </header>

      <div className="card">
        {state.events.length === 0 ? (
          <div className="empty-state">هنوز رخدادی ثبت نشده است.</div>
        ) : (
          state.events.map((ev) => {
            const newCritical = ev.criticalAlertsAfter - ev.criticalAlertsBefore;
            return (
              <div key={ev.id} className="event-item">
                <div className="event-time">{ev.time}</div>
                <div>
                  <strong>{ev.type}</strong> — {ev.entity}
                </div>
                <div className="hint">
                  {ev.before} ← {ev.after}
                </div>
                {ev.reason && <div className="hint">دلیل: {ev.reason}</div>}
                {newCritical !== 0 && (
                  <div className="hint" style={{ color: newCritical > 0 ? 'var(--critical)' : 'var(--confirmed)' }}>
                    {newCritical > 0 ? `${newCritical} هشدار بحرانی جدید ایجاد شد` : `${Math.abs(newCritical)} هشدار بحرانی برطرف شد`}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </>
  );
}
